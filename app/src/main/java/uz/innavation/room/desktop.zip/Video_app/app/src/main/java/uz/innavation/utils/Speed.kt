package uz.innavation.utils

data class Speed(var speed: Float, var time: Long)